#!/bin/bash

# Script 2: Evasion & Anti-Forensics Analysis
# Covers: Living off the land, geofencing, self-destruction, credential harvesting, anti-analysis

echo "========================================="
echo "SCRIPT 2: Evasion & Anti-Forensics Analysis"
echo "Started: $(date)"
echo "========================================="
echo ""

# ============================================================================
# LIVING OFF THE LAND
# ============================================================================

echo "=== LIVING OFF THE LAND ==="
echo ""

echo "--- CoreWLAN Framework Usage ---"
lsof 2>/dev/null | grep -i corewlan
echo ""

echo "--- CoreWLAN Framework Files ---"
ls -laR /System/Library/Frameworks/CoreWLAN.framework/ 2>/dev/null | head -100
echo ""

echo "--- NetworkExtension Framework Usage ---"
lsof 2>/dev/null | grep -i networkextension
echo ""

echo "--- NetworkExtension Framework Files ---"
ls -laR /System/Library/Frameworks/NetworkExtension.framework/ 2>/dev/null | head -100
echo ""

echo "--- CoreLocation Framework Usage ---"
lsof 2>/dev/null | grep -i corelocation
echo ""

echo "--- SystemConfiguration Framework Usage ---"
lsof 2>/dev/null | grep -i systemconfiguration
echo ""

echo "--- configd Usage ---"
lsof 2>/dev/null | grep configd | head -200
echo ""

echo "--- configd Process Details ---"
ps aux | grep configd | grep -v grep
echo ""

echo "--- Network Framework Usage ---"
lsof 2>/dev/null | grep -i "network.framework"
echo ""

echo "--- Network Tools in Active Use ---"
ps aux | grep -iE "networksetup|scutil|ifconfig|airport|ipconfig|route" | grep -v grep
echo ""

echo "--- Airport Utility Usage ---"
lsof 2>/dev/null | grep -i airport
echo ""

echo "--- Airport Binary ---"
ls -la /System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport 2>/dev/null
echo ""

echo "--- System Network Binaries (usr/bin) ---"
ls -la /usr/bin/ 2>/dev/null | grep -iE "net|ip|route|arp|dns|ping|trace"
echo ""

echo "--- System Network Binaries (usr/sbin) ---"
ls -la /usr/sbin/ 2>/dev/null | grep -iE "net|ip|route|arp|dns|ping|trace"
echo ""

echo "--- Recently Executed Network Commands ---"
log show --predicate 'process == "networksetup" OR process == "scutil" OR process == "ifconfig"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Network Utility Processes ---"
ps aux | grep -iE "netstat|nettop|lsof|tcpdump|wireshark|nmap" | grep -v grep
echo ""

echo "--- System Extensions ---"
systemextensionsctl list 2>/dev/null
echo ""

echo "--- Network Extension Processes ---"
ps aux | grep -i "nesession\|NEAgent" | grep -v grep
echo ""

echo "--- VPN Framework Usage ---"
lsof 2>/dev/null | grep -iE "vpn|ipsec"
echo ""

echo "--- Packet Capture Capabilities ---"
ls -la /dev/bpf* 2>/dev/null
echo ""

echo "--- BPF Device Access ---"
lsof /dev/bpf* 2>/dev/null
echo ""

echo "--- Native Network Diagnostics Usage ---"
log show --predicate 'process == "ping" OR process == "traceroute" OR process == "nslookup" OR process == "dig" OR process == "host"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Network Preference APIs ---"
log show --predicate 'subsystem == "com.apple.preferences.network"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Built-in WiFi Debugging ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "debug"' --last 7d 2>/dev/null | tail -300
echo ""

# ============================================================================
# GEOFENCING
# ============================================================================

echo "=== GEOFENCING ==="
echo ""

echo "--- Location Services Status ---"
ps aux | grep -i "locationd" | grep -v grep
echo ""

echo "--- Location Services Logs ---"
log show --predicate 'subsystem == "com.apple.locationd"' --last 7d --style syslog 2>/dev/null | tail -1500
echo ""

echo "--- CoreLocation Daemon Activity ---"
log show --predicate 'process == "locationd"' --last 7d 2>/dev/null | tail -1000
echo ""

echo "--- WiFi-Based Location Requests ---"
log show --predicate 'subsystem == "com.apple.locationd" AND eventMessage CONTAINS "wifi"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Geographic Region Monitoring ---"
log show --predicate 'eventMessage CONTAINS "region" OR eventMessage CONTAINS "geofence"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Routine Location Data ---"
if [ -d "$HOME/Library/Caches/com.apple.routined" ]; then
    ls -laR "$HOME/Library/Caches/com.apple.routined" 2>/dev/null
fi
echo ""

echo "--- Significant Location Changes ---"
log show --predicate 'subsystem == "com.apple.routined"' --last 30d 2>/dev/null | tail -500
echo ""

echo "--- Location Authorization Changes ---"
log show --predicate 'eventMessage CONTAINS "authorization" AND subsystem == "com.apple.locationd"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Geographic Preferences ---"
if [ -f "$HOME/Library/Preferences/com.apple.preferences.timezone.plist" ]; then
    plutil -p "$HOME/Library/Preferences/com.apple.preferences.timezone.plist" 2>/dev/null
fi
echo ""

echo "--- Time Zone Settings ---"
systemsetup -gettimezone 2>/dev/null
echo ""

echo "--- Time Zone Changes ---"
log show --predicate 'eventMessage CONTAINS "timezone"' --last 30d 2>/dev/null | tail -200
echo ""

echo "--- AirPort Environment Profile ---"
system_profiler SPAirPortDataType
echo ""

echo "--- WiFi Country Code ---"
/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport -I 2>/dev/null | grep -i "country"
echo ""

echo "--- Network Time Settings ---"
systemsetup -getusingnetworktime 2>/dev/null
systemsetup -getnetworktimeserver 2>/dev/null
echo ""

echo "--- Find My Network Activity ---"
log show --predicate 'subsystem CONTAINS "findmy"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Find My Location Beacons ---"
log show --predicate 'subsystem CONTAINS "findmy" AND eventMessage CONTAINS "beacon"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Location-Based Alerts ---"
log show --predicate 'eventMessage CONTAINS "location" AND eventMessage CONTAINS "alert"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- App Location Permissions ---"
log show --predicate 'subsystem == "com.apple.locationd" AND eventMessage CONTAINS "app"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Background Location Usage ---"
log show --predicate 'subsystem == "com.apple.locationd" AND eventMessage CONTAINS "background"' --last 7d 2>/dev/null | tail -300
echo ""

# ============================================================================
# SELF-DESTRUCTION/ANTI-FORENSICS
# ============================================================================

echo "=== SELF-DESTRUCTION/ANTI-FORENSICS ==="
echo ""

echo "--- File Deletion Events (7 Days) ---"
log show --predicate 'eventMessage CONTAINS "delete" OR eventMessage CONTAINS "remove" OR eventMessage CONTAINS "unlink"' --last 7d 2>/dev/null | tail -1500
echo ""

echo "--- Clear/Wipe Events ---"
log show --predicate 'eventMessage CONTAINS "clear" OR eventMessage CONTAINS "wipe" OR eventMessage CONTAINS "erase"' --last 7d 2>/dev/null | tail -1000
echo ""

echo "--- Trash/Removal Activity ---"
log show --predicate 'eventMessage CONTAINS "trash" OR eventMessage CONTAINS "rm " OR eventMessage CONTAINS "rmdir"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- File System Modifications ---"
log show --predicate 'subsystem == "com.apple.filesystemui" OR subsystem == "com.apple.fskit"' --last 7d 2>/dev/null | tail -1000
echo ""

echo "--- Log Rotation Status ---"
ls -la /var/log/*.gz /var/log/*.old /var/log/*.bz2 2>/dev/null
echo ""

echo "--- Log File Timestamps ---"
ls -lat /var/log/ 2>/dev/null | head -50
echo ""

echo "--- Recent Log File Modifications (7 Days) ---"
find /var/log -type f -mtime -7 -exec ls -la {} \; 2>/dev/null
echo ""

echo "--- System Log Files ---"
ls -la /var/log/system.log* 2>/dev/null
echo ""

echo "--- ASL Database ---"
ls -la /var/log/asl/ 2>/dev/null | head -50
echo ""

echo "--- Diagnostic Messages ---"
ls -laR /var/log/DiagnosticMessages/ 2>/dev/null | head -500
echo ""

echo "--- Cleaned/Empty Caches ---"
find ~/Library/Caches -type d -empty 2>/dev/null | head -100
echo ""

echo "--- Recent Cache Deletions ---"
log show --predicate 'eventMessage CONTAINS "cache" AND (eventMessage CONTAINS "delete" OR eventMessage CONTAINS "clear")' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Temporary File Cleanup ---"
ls -la /tmp/ 2>/dev/null
ls -la /var/tmp/ 2>/dev/null
echo ""

echo "--- Temporary Directory Timestamps ---"
stat /tmp /var/tmp 2>/dev/null
echo ""

echo "--- Secure Deletion Activity ---"
log show --predicate 'eventMessage CONTAINS "srm" OR eventMessage CONTAINS "secure delete"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Shredding/Overwrite Activity ---"
log show --predicate 'eventMessage CONTAINS "shred" OR eventMessage CONTAINS "overwrite"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- Privacy Preference Changes ---"
log show --predicate 'subsystem == "com.apple.privacy" OR eventMessage CONTAINS "privacy"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Network Configuration Resets ---"
log show --predicate 'eventMessage CONTAINS "reset" AND eventMessage CONTAINS "network"' --last 30d 2>/dev/null | tail -300
echo ""

echo "--- WiFi Configuration Deletions ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "delete"' --last 30d 2>/dev/null | tail -300
echo ""

echo "--- Keychain Modifications ---"
log show --predicate 'process == "securityd" AND eventMessage CONTAINS "delete"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Configuration Profile Removals ---"
log show --predicate 'eventMessage CONTAINS "profile" AND eventMessage CONTAINS "remove"' --last 30d 2>/dev/null | tail -200
echo ""

echo "--- Anti-Forensics Tool Detection ---"
ps aux | grep -iE "ccleaner|bleachbit|eraser|antiforensics" | grep -v grep
echo ""

echo "--- Log Sanitization ---"
log show --predicate 'eventMessage CONTAINS "sanitize" OR eventMessage CONTAINS "redact"' --last 7d 2>/dev/null | tail -200
echo ""

# ============================================================================
# CREDENTIAL HARVESTING
# ============================================================================

echo "=== CREDENTIAL HARVESTING ==="
echo ""

echo "--- WiFi Keychain Entries ---"
security dump-keychain 2>/dev/null | grep -iE "wifi|airport|802\.1x|wpa|eap" | head -500
echo ""

echo "--- AirPort Passwords ---"
security dump-keychain 2>/dev/null | grep -B3 -A3 -i "airport" | head -200
echo ""

echo "--- 802.1X Credentials ---"
security dump-keychain 2>/dev/null | grep -B3 -A3 -iE "802\.1x|eap" | head -200
echo ""

echo "--- WPA Pre-Shared Keys ---"
security dump-keychain 2>/dev/null | grep -B3 -A3 -i "wpa" | head -200
echo ""

echo "--- System Keychain WiFi Entries ---"
security dump-keychain /Library/Keychains/System.keychain 2>/dev/null | grep -iE "wifi|airport|network" | head -500
echo ""

echo "--- Network Password Items ---"
security dump-keychain 2>/dev/null | grep -i "network password" | head -200
echo ""

echo "--- WiFi Preference Files ---"
find ~/Library/Preferences -name "*wifi*" -o -name "*airport*" -o -name "*network*" 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- System WiFi Preferences ---"
find /Library/Preferences -name "*wifi*" -o -name "*airport*" -o -name "*network*" 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- SystemConfiguration Credentials ---"
ls -la /Library/Preferences/SystemConfiguration/ 2>/dev/null
echo ""

echo "--- Network Interfaces Plist ---"
if [ -f "/Library/Preferences/SystemConfiguration/NetworkInterfaces.plist" ]; then
    plutil -p "/Library/Preferences/SystemConfiguration/NetworkInterfaces.plist" 2>/dev/null
fi
echo ""

echo "--- 802.1X Profiles ---"
find /Library/Preferences/SystemConfiguration -name "*802*" -o -name "*eap*" 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- EAPoL Client Configuration ---"
if [ -f "/Library/Preferences/SystemConfiguration/com.apple.eapolclient.configuration.plist" ]; then
    plutil -p "/Library/Preferences/SystemConfiguration/com.apple.eapolclient.configuration.plist" 2>/dev/null
fi
echo ""

echo "--- VPN Credentials ---"
security dump-keychain 2>/dev/null | grep -iE "vpn|ipsec|l2tp|pptp|ikev2" | head -300
echo ""

echo "--- VPN Configurations ---"
find /Library/Preferences/SystemConfiguration -name "*vpn*" -o -name "*ipsec*" 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- Proxy Authentication Credentials ---"
security dump-keychain 2>/dev/null | grep -i "proxy" | head -200
echo ""

echo "--- Stored Network Passwords ---"
security dump-keychain 2>/dev/null | grep -i "password" | grep -iE "network|wifi|internet" | head -500
echo ""

echo "--- Certificate Authorities ---"
security find-certificate -a /System/Library/Keychains/SystemRootCertificates.keychain 2>/dev/null | grep -E "labl|issu" | head -300
echo ""

echo "--- User Installed Certificates ---"
security find-certificate -a ~/Library/Keychains/login.keychain-db 2>/dev/null | grep -E "labl|issu|subj" | head -500
echo ""

echo "--- System Keychain Certificates ---"
security find-certificate -a /Library/Keychains/System.keychain 2>/dev/null | grep -E "labl|issu|subj" | head -500
echo ""

echo "--- Identity Preferences ---"
if [ -f "$HOME/Library/Preferences/com.apple.security.identities.plist" ]; then
    plutil -p "$HOME/Library/Preferences/com.apple.security.identities.plist" 2>/dev/null
fi
echo ""

echo "--- Keychain Access Logs ---"
log show --predicate 'process == "securityd"' --last 7d 2>/dev/null | grep -iE "wifi|network|password" | tail -500
echo ""

echo "--- Credential Access Events ---"
log show --predicate 'eventMessage CONTAINS "credential" OR eventMessage CONTAINS "password"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Security Agent Activity ---"
log show --predicate 'process == "SecurityAgent"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Authentication Attempts ---"
log show --predicate 'eventMessage CONTAINS "authentication"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Keychain Item Access ---"
log show --predicate 'subsystem == "com.apple.securityd" AND eventMessage CONTAINS "access"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Browser Saved Passwords ---"
find ~/Library/Application\ Support -name "*Login*" -o -name "*Password*" -o -name "*Credential*" 2>/dev/null | head -100
echo ""

echo "--- Password Manager Databases ---"
find ~/Library -name "*password*" -o -name "*credential*" -o -name "*vault*" 2>/dev/null | grep -v Cache | head -100
echo ""

# ============================================================================
# ANTI-ANALYSIS AND DETECTION EVASION
# ============================================================================

echo "=== ANTI-ANALYSIS AND DETECTION EVASION ==="
echo ""

echo "--- Virtual Machine Detection ---"
system_profiler SPHardwareDataType | grep -iE "virtual|vmware|parallels|virtualbox|qemu|kvm"
echo ""

echo "--- Hardware Model ---"
system_profiler SPHardwareDataType | grep "Model"
echo ""

echo "--- Serial Number Check ---"
system_profiler SPHardwareDataType | grep "Serial Number"
echo ""

echo "--- Virtualization Indicators in IO Registry ---"
ioreg -l | grep -iE "virtual|vmware|parallels|vbox|qemu" | head -100
echo ""

echo "--- Hypervisor Detection ---"
sysctl -a | grep -i hypervisor
echo ""

echo "--- Sandbox Environment Detection ---"
ps aux | grep -iE "sandbox|container|vm" | grep -v grep
echo ""

echo "--- Security Tool Detection ---"
ps aux | grep -iE "little.?snitch|lulu|blockblock|knockknock|kextviewer|taskexplorer|oversight" | grep -v grep
echo ""

echo "--- Security Software Processes ---"
ps aux | grep -iE "antivirus|firewall|security|protection" | grep -v grep
echo ""

echo "--- Packet Capture Tools ---"
ps aux | grep -iE "tcpdump|wireshark|tshark|sniff|pcap|ettercap" | grep -v grep
echo ""

echo "--- Network Monitoring Tools ---"
ps aux | grep -iE "charles|burp|mitmproxy|fiddler|proxyman" | grep -v grep
echo ""

echo "--- IDS/IPS Detection ---"
ps aux | grep -iE "snort|suricata|bro|zeek|ids|ips" | grep -v grep
echo ""

echo "--- Debugging Tools ---"
ps aux | grep -iE "lldb|gdb|dtrace|dtruss|fs_usage|instruments|sample" | grep -v grep
echo ""

echo "--- Forensic Tools ---"
ps aux | grep -iE "volatility|autopsy|sleuthkit|foremost|photorec|testdisk" | grep -v grep
echo ""

echo "--- System Tracing ---"
ps aux | grep -iE "trace|dtrace|ktrace" | grep -v grep
echo ""

echo "--- File System Monitoring ---"
ps aux | grep -iE "fs_usage|opensnoop|fseventer" | grep -v grep
echo ""

echo "--- Network Packet Inspection ---"
lsof /dev/bpf* 2>/dev/null
echo ""

echo "--- Promiscuous Mode Detection ---"
ifconfig | grep -i promisc
echo ""

echo "--- Honeypot Network SSIDs ---"
networksetup -listpreferredwirelessnetworks en0 2>/dev/null | grep -iE "honey|trap|canary|decoy|fake|test"
echo ""

echo "--- Security Vendor Networks ---"
networksetup -listpreferredwirelessnetworks en0 2>/dev/null | grep -iE "sophos|mcafee|symantec|kaspersky|trend|crowdstrike|palo.?alto|fortinet|checkpoint|fireeye"
echo ""

echo "--- Analysis Lab Networks ---"
networksetup -listpreferredwirelessnetworks en0 2>/dev/null | grep -iE "lab|research|analysis|sandbox|malware"
echo ""

echo "--- Unusual MAC Addresses in ARP ---"
arp -a | grep -iE "00:00:00|ff:ff:ff|00:0c:29|00:1c:14|00:50:56|08:00:27"
echo ""

echo "--- Known Vendor OUIs (VM Detection) ---"
arp -a | grep -iE "VMware|VirtualBox|Parallels|QEMU"
echo ""

echo "--- Debugging Enabled ---"
log show --predicate 'eventMessage CONTAINS "debug" AND eventMessage CONTAINS "enable"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Developer Mode ---"
DevToolsSecurity -status 2>/dev/null
echo ""

echo "--- System Integrity Protection Status ---"
csrutil status 2>/dev/null
echo ""

echo "--- Secure Boot Status ---"
if [ -x /usr/sbin/nvram ]; then
    nvram -p | grep -i "secure"
fi
echo ""

echo "--- Analysis Environment Indicators ---"
log show --predicate 'eventMessage CONTAINS "analysis" OR eventMessage CONTAINS "forensic"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- Timing Analysis ---"
sysctl kern.boottime
uptime
echo ""

echo "--- CPU Throttling/Emulation ---"
sysctl -a | grep cpu | head -50
echo ""

echo "--- Network Delay Indicators ---"
log show --predicate 'eventMessage CONTAINS "latency" OR eventMessage CONTAINS "delay"' --last 7d 2>/dev/null | tail -200
echo ""

echo ""
echo "========================================="
echo "Script 2 Complete: $(date)"
echo "========================================="
echo ""