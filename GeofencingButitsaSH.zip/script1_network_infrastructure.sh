#!/bin/bash

# Script 1: Network & Infrastructure Analysis
# Covers: Network scanning, router attacks, protocol-level attacks, captive portals

echo "========================================="
echo "SCRIPT 1: Network & Infrastructure Analysis"
echo "Started: $(date)"
echo "========================================="
echo ""

# ============================================================================
# NETWORK SCANNING AND ENUMERATION
# ============================================================================

echo "=== NETWORK SCANNING AND ENUMERATION ==="
echo ""

echo "--- WiFi System Preferences ---"
if [ -f "/Library/Preferences/SystemConfiguration/com.apple.airport.preferences.plist" ]; then
    plutil -p "/Library/Preferences/SystemConfiguration/com.apple.airport.preferences.plist" 2>/dev/null
fi
echo ""

echo "--- Known WiFi Networks ---"
if [ -f "$HOME/Library/Preferences/com.apple.wifi.known-networks.plist" ]; then
    plutil -p "$HOME/Library/Preferences/com.apple.wifi.known-networks.plist" 2>/dev/null
fi
echo ""

echo "--- Preferred Wireless Networks ---"
networksetup -listpreferredwirelessnetworks en0 2>/dev/null
networksetup -listpreferredwirelessnetworks en1 2>/dev/null
echo ""

echo "--- Current WiFi Network ---"
networksetup -getairportnetwork en0 2>/dev/null
networksetup -getairportnetwork en1 2>/dev/null
echo ""

echo "--- WiFi Power Status ---"
networksetup -getairportpower en0 2>/dev/null
networksetup -getairportpower en1 2>/dev/null
echo ""

echo "--- ARP Cache (Connected Devices) ---"
arp -a
echo ""

echo "--- ARP Cache Statistics ---"
arp -a | wc -l
echo ""

echo "--- Routing Table ---"
netstat -rn
echo ""

echo "--- Default Gateway ---"
netstat -rn | grep default
echo ""

echo "--- DHCP Lease Information (en0) ---"
ipconfig getpacket en0 2>/dev/null
echo ""

echo "--- DHCP Lease Information (en1) ---"
ipconfig getpacket en1 2>/dev/null
echo ""

echo "--- Network Interfaces Overview ---"
ifconfig -a
echo ""

echo "--- Active Network Connections ---"
netstat -an
echo ""

echo "--- Established Connections Only ---"
netstat -an | grep ESTABLISHED
echo ""

echo "--- Listening Ports ---"
netstat -an | grep LISTEN
echo ""

echo "--- WiFi Scan Results ---"
/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport -s 2>/dev/null
echo ""

echo "--- Current WiFi Interface Details ---"
/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport -I 2>/dev/null
echo ""

echo "--- Network Service Order ---"
networksetup -listnetworkserviceorder
echo ""

echo "--- All Network Services ---"
networksetup -listallnetworkservices
echo ""

echo "--- Hardware Ports ---"
networksetup -listallhardwareports
echo ""

echo "--- System Network Preferences ---"
if [ -f "/Library/Preferences/SystemConfiguration/preferences.plist" ]; then
    plutil -p "/Library/Preferences/SystemConfiguration/preferences.plist" 2>/dev/null | head -1000
fi
echo ""

echo "--- Network Interfaces Configuration ---"
if [ -f "/Library/Preferences/SystemConfiguration/NetworkInterfaces.plist" ]; then
    plutil -p "/Library/Preferences/SystemConfiguration/NetworkInterfaces.plist" 2>/dev/null
fi
echo ""

echo "--- Current Network Location ---"
networksetup -getcurrentlocation
echo ""

echo "--- All Network Locations ---"
networksetup -listlocations
echo ""

echo "--- WiFi Activity Logs (Last 7 Days) ---"
log show --predicate 'subsystem == "com.apple.wifi"' --last 7d --style syslog 2>/dev/null | tail -2000
echo ""

echo "--- Airport Daemon Activity ---"
log show --predicate 'process == "airportd"' --last 7d --style syslog 2>/dev/null | tail -1000
echo ""

echo "--- Network Configuration Changes ---"
log show --predicate 'subsystem == "com.apple.networkd"' --last 7d 2>/dev/null | tail -1000
echo ""

echo "--- configd Activity ---"
log show --predicate 'process == "configd"' --last 7d 2>/dev/null | tail -1000
echo ""

echo "--- Network Extension Activity ---"
log show --predicate 'subsystem == "com.apple.networkextension"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Network Probe Requests ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "probe"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- WiFi Roaming Events ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "roam"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Network Interface State Changes ---"
log show --predicate 'eventMessage CONTAINS "interface" AND eventMessage CONTAINS "state"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- DHCP Activity Logs ---"
log show --predicate 'process == "bootpd" OR eventMessage CONTAINS "DHCP"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Port Scan Detection ---"
log show --predicate 'eventMessage CONTAINS "port" AND eventMessage CONTAINS "scan"' --last 7d 2>/dev/null | tail -200
echo ""

# ============================================================================
# ROUTER/MODEM ATTACK INDICATORS
# ============================================================================

echo "=== ROUTER/MODEM ATTACK INDICATORS ==="
echo ""

echo "--- DNS Configuration ---"
scutil --dns
echo ""

echo "--- DNS Servers Only ---"
scutil --dns | grep "nameserver"
echo ""

echo "--- Hosts File ---"
cat /etc/hosts
echo ""

echo "--- Hosts File Timestamp ---"
stat /etc/hosts 2>/dev/null
echo ""

echo "--- Resolver Directory ---"
ls -la /etc/resolver/ 2>/dev/null
echo ""

echo "--- Resolver Configurations ---"
for resolver in /etc/resolver/*; do
    if [ -f "$resolver" ]; then
        echo "=== $resolver ==="
        cat "$resolver"
        echo ""
    fi
done
echo ""

echo "--- Web Proxy Settings (All Services) ---"
networksetup -listallnetworkservices 2>/dev/null | while IFS= read -r service; do
    if [ "$service" != "An asterisk (*) denotes that a network service is disabled." ]; then
        echo "Service: $service"
        networksetup -getwebproxy "$service" 2>/dev/null
        echo ""
    fi
done
echo ""

echo "--- Secure Web Proxy Settings ---"
networksetup -listallnetworkservices 2>/dev/null | while IFS= read -r service; do
    if [ "$service" != "An asterisk (*) denotes that a network service is disabled." ]; then
        echo "Service: $service"
        networksetup -getsecurewebproxy "$service" 2>/dev/null
        echo ""
    fi
done
echo ""

echo "--- Auto Proxy Configuration ---"
networksetup -listallnetworkservices 2>/dev/null | while IFS= read -r service; do
    if [ "$service" != "An asterisk (*) denotes that a network service is disabled." ]; then
        echo "Service: $service"
        networksetup -getautoproxyurl "$service" 2>/dev/null
        echo ""
    fi
done
echo ""

echo "--- FTP Proxy Settings ---"
networksetup -listallnetworkservices 2>/dev/null | while IFS= read -r service; do
    if [ "$service" != "An asterisk (*) denotes that a network service is disabled." ]; then
        echo "Service: $service"
        networksetup -getftpproxy "$service" 2>/dev/null
        echo ""
    fi
done
echo ""

echo "--- SOCKS Proxy Settings ---"
networksetup -listallnetworkservices 2>/dev/null | while IFS= read -r service; do
    if [ "$service" != "An asterisk (*) denotes that a network service is disabled." ]; then
        echo "Service: $service"
        networksetup -getsocksfirewallproxy "$service" 2>/dev/null
        echo ""
    fi
done
echo ""

echo "--- Streaming Proxy Settings ---"
networksetup -listallnetworkservices 2>/dev/null | while IFS= read -r service; do
    if [ "$service" != "An asterisk (*) denotes that a network service is disabled." ]; then
        echo "Service: $service"
        networksetup -getstreamingproxy "$service" 2>/dev/null
        echo ""
    fi
done
echo ""

echo "--- Gopher Proxy Settings ---"
networksetup -listallnetworkservices 2>/dev/null | while IFS= read -r service; do
    if [ "$service" != "An asterisk (*) denotes that a network service is disabled." ]; then
        echo "Service: $service"
        networksetup -getgopherproxy "$service" 2>/dev/null
        echo ""
    fi
done
echo ""

echo "--- Proxy Bypass Domains ---"
networksetup -listallnetworkservices 2>/dev/null | while IFS= read -r service; do
    if [ "$service" != "An asterisk (*) denotes that a network service is disabled." ]; then
        echo "Service: $service"
        networksetup -getproxybypassdomains "$service" 2>/dev/null
        echo ""
    fi
done
echo ""

echo "--- Passive FTP Mode ---"
networksetup -listallnetworkservices 2>/dev/null | while IFS= read -r service; do
    if [ "$service" != "An asterisk (*) denotes that a network service is disabled." ]; then
        echo "Service: $service"
        networksetup -getpassiveftp "$service" 2>/dev/null
        echo ""
    fi
done
echo ""

echo "--- UPnP/SSDP Related Processes ---"
ps aux | grep -iE "upnp|ssdp" | grep -v grep
echo ""

echo "--- mDNS/Bonjour Processes ---"
ps aux | grep -iE "mdns|bonjour" | grep -v grep
echo ""

echo "--- DNS Responder Processes ---"
ps aux | grep -i "mDNSResponder\|DNSResponder" | grep -v grep
echo ""

echo "--- Network Discovery Services ---"
ps aux | grep -iE "discoveryd|configd" | grep -v grep
echo ""

echo "--- Gateway MAC Address ---"
default_gw=$(netstat -rn | grep default | awk '{print $2}' | head -1)
if [ ! -z "$default_gw" ]; then
    arp -a | grep "$default_gw"
fi
echo ""

echo "--- Router Admin Access Attempts ---"
log show --predicate 'eventMessage CONTAINS "192.168" OR eventMessage CONTAINS "10.0.0" OR eventMessage CONTAINS "172.16"' --last 7d 2>/dev/null | grep -iE "admin|login|auth" | tail -500
echo ""

echo "--- UPnP Port Forwarding Activity ---"
log show --predicate 'eventMessage CONTAINS "UPnP" OR eventMessage CONTAINS "NAT-PMP"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- DNS Hijacking Indicators ---"
log show --predicate 'process == "mDNSResponder" AND eventMessage CONTAINS "redirect"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- Unusual DNS Responses ---"
log show --predicate 'process == "mDNSResponder"' --last 7d 2>/dev/null | grep -iE "nxdomain|refused|servfail" | tail -300
echo ""

# ============================================================================
# PROTOCOL-LEVEL ATTACKS
# ============================================================================

echo "=== PROTOCOL-LEVEL ATTACKS ==="
echo ""

echo "--- WPA/WPA2/WPA3 Security Events ---"
log show --predicate 'subsystem == "com.apple.wifi" AND (eventMessage CONTAINS "WPA" OR eventMessage CONTAINS "security")' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Authentication Failures ---"
log show --predicate 'eventMessage CONTAINS "auth" AND eventMessage CONTAINS "fail"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Deauthentication Events ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "deauth"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Disassociation Events ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "disassoc"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- DHCP Events and Issues ---"
log show --predicate 'process == "bootpd" OR eventMessage CONTAINS "DHCP"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- ARP Activity ---"
log show --predicate 'eventMessage CONTAINS "ARP"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- ARP Spoofing Detection ---"
arp -a | awk '{print $4}' | sort | uniq -d
echo ""

echo "--- Duplicate IP Detection ---"
log show --predicate 'eventMessage CONTAINS "duplicate" OR eventMessage CONTAINS "conflict"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Rogue DHCP Server Detection ---"
log show --predicate 'eventMessage CONTAINS "DHCP" AND eventMessage CONTAINS "server"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- 802.11 Frame Errors ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "error"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Beacon Flood Detection ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "beacon"' --last 1d 2>/dev/null | wc -l
echo ""

echo "--- Management Frame Anomalies ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "management"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Key Reinstallation Indicators ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "key"' --last 7d 2>/dev/null | grep -iE "reinstall|rekey" | tail -200
echo ""

echo "--- WPA Handshake Issues ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "handshake"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- 4-Way Handshake Failures ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "4-way"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- EAPoL Frame Activity ---"
log show --predicate 'eventMessage CONTAINS "EAPoL"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- Network Downgrade Attempts ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "downgrade"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- Encryption Weakening ---"
log show --predicate 'subsystem == "com.apple.wifi" AND (eventMessage CONTAINS "WEP" OR eventMessage CONTAINS "open" OR eventMessage CONTAINS "none")' --last 7d 2>/dev/null | tail -200
echo ""

# ============================================================================
# CAPTIVE PORTAL EXPLOITATION
# ============================================================================

echo "=== CAPTIVE PORTAL EXPLOITATION ==="
echo ""

echo "--- Captive Portal Detection Activity ---"
log show --predicate 'subsystem CONTAINS "captive" OR eventMessage CONTAINS "portal"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Captive Network Assistant Process ---"
ps aux | grep -i "captivenetworkassistant" | grep -v grep
echo ""

echo "--- Captive Network Assistant Logs ---"
log show --predicate 'process == "CaptiveNetworkAssistant"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Portal Redirect Activity ---"
log show --predicate 'eventMessage CONTAINS "redirect" AND (subsystem CONTAINS "captive" OR process == "CaptiveNetworkAssistant")' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Apple Captive Portal Checks ---"
log show --predicate 'eventMessage CONTAINS "captive.apple.com" OR eventMessage CONTAINS "apple.com/library/test"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- HTTP Captive Detection Requests ---"
log show --predicate 'eventMessage CONTAINS "hotspot" OR eventMessage CONTAINS "success.txt"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Browser Captive Portal Interactions ---"
log show --predicate 'process == "Safari" AND eventMessage CONTAINS "captive"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Captive Portal Authentication ---"
log show --predicate 'eventMessage CONTAINS "captive" AND eventMessage CONTAINS "auth"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Portal Bypass Attempts ---"
log show --predicate 'eventMessage CONTAINS "captive" AND eventMessage CONTAINS "bypass"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- Fake Portal Detection ---"
log show --predicate 'eventMessage CONTAINS "captive" AND eventMessage CONTAINS "invalid"' --last 7d 2>/dev/null | tail -200
echo ""

# ============================================================================
# ADVANCED ROUTER COMPROMISE
# ============================================================================

echo "=== ADVANCED ROUTER COMPROMISE ==="
echo ""

echo "--- Gateway Information ---"
netstat -rn | grep default
echo ""

echo "--- Gateway ARP Entry ---"
default_gw=$(netstat -rn | grep default | awk '{print $2}' | head -1)
if [ ! -z "$default_gw" ]; then
    arp -n | grep "$default_gw"
fi
echo ""

echo "--- Connections to Gateway ---"
lsof -i -n -P 2>/dev/null | grep "$default_gw"
echo ""

echo "--- DNS Server Tampering ---"
scutil --dns | grep "nameserver" | grep -vE "8\.8\.8\.8|8\.8\.4\.4|1\.1\.1\.1|1\.0\.0\.1|208\.67\.222\.222|208\.67\.220\.220"
echo ""

echo "--- Custom DNS Configurations ---"
for service in $(networksetup -listallnetworkservices 2>/dev/null | grep -v "^An asterisk"); do
    dns_servers=$(networksetup -getdnsservers "$service" 2>/dev/null)
    if [ "$dns_servers" != "There aren't any DNS Servers set on"* ]; then
        echo "Service: $service"
        echo "$dns_servers"
        echo ""
    fi
done
echo ""

echo "--- Router Firmware Update Activity ---"
log show --predicate 'eventMessage CONTAINS "firmware" OR eventMessage CONTAINS "upgrade"' --last 30d 2>/dev/null | grep -iE "router|gateway|modem" | tail -200
echo ""

echo "--- TR-069/CWMP Activity ---"
log show --predicate 'eventMessage CONTAINS "TR-069" OR eventMessage CONTAINS "CWMP"' --last 30d 2>/dev/null | tail -200
echo ""

echo "--- UPnP IGD Activity ---"
log show --predicate 'eventMessage CONTAINS "IGD" OR eventMessage CONTAINS "InternetGatewayDevice"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- Port Forwarding Rules ---"
lsof -i -n -P 2>/dev/null | awk '{print $9}' | grep -oE ":[0-9]+" | sort -u
echo ""

echo "--- NAT-PMP Activity ---"
log show --predicate 'eventMessage CONTAINS "NAT-PMP"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- Router Management Interface Access ---"
log show --predicate 'eventMessage CONTAINS ":80" OR eventMessage CONTAINS ":8080" OR eventMessage CONTAINS ":443"' --last 7d 2>/dev/null | grep -E "192\.168\.|10\.|172\.16\." | tail -500
echo ""

echo "--- SNMP Activity ---"
lsof -i :161 -i :162 2>/dev/null
echo ""

echo "--- Router Configuration Backup ---"
log show --predicate 'eventMessage CONTAINS "backup" OR eventMessage CONTAINS "config"' --last 30d 2>/dev/null | grep -iE "router|gateway" | tail -200
echo ""

# ============================================================================
# NETWORK DIAGNOSTICS
# ============================================================================

echo "=== ADDITIONAL NETWORK DIAGNOSTICS ==="
echo ""

echo "--- All Hardware Ports ---"
networksetup -listallhardwareports
echo ""

echo "--- IPv4 Configuration (All Services) ---"
networksetup -listallnetworkservices 2>/dev/null | while IFS= read -r service; do
    if [ "$service" != "An asterisk (*) denotes that a network service is disabled." ]; then
        echo "=== Service: $service ==="
        networksetup -getinfo "$service" 2>/dev/null
        echo ""
    fi
done
echo ""

echo "--- IPv6 Configuration ---"
networksetup -listallnetworkservices 2>/dev/null | while IFS= read -r service; do
    if [ "$service" != "An asterisk (*) denotes that a network service is disabled." ]; then
        echo "Service: $service"
        ipv6=$(networksetup -getinfo "$service" 2>/dev/null | grep -i "ipv6")
        if [ ! -z "$ipv6" ]; then
            echo "$ipv6"
        fi
        echo ""
    fi
done
echo ""

echo "--- MTU Settings ---"
networksetup -listallnetworkservices 2>/dev/null | while IFS= read -r service; do
    if [ "$service" != "An asterisk (*) denotes that a network service is disabled." ]; then
        echo "Service: $service"
        networksetup -getMTU "$service" 2>/dev/null
        echo ""
    fi
done
echo ""

echo "--- Media Settings ---"
networksetup -listallnetworkservices 2>/dev/null | while IFS= read -r service; do
    if [ "$service" != "An asterisk (*) denotes that a network service is disabled." ]; then
        echo "Service: $service"
        networksetup -getmedia "$service" 2>/dev/null
        echo ""
    fi
done
echo ""

echo "--- Wake on Network Access ---"
networksetup -getwakeonnetworkaccess 2>/dev/null
echo ""

echo "--- Network Service Order ---"
networksetup -listnetworkserviceorder
echo ""

echo "--- DNS Search Domains ---"
scutil --dns | grep "search domain"
echo ""

echo "--- Network Interface Statistics ---"
netstat -i
echo ""

echo "--- Interface Byte Counts ---"
netstat -ib
echo ""

echo "--- Network Protocol Statistics ---"
netstat -s
echo ""

echo "--- Multicast Group Memberships ---"
netstat -g
echo ""

echo "--- IPv6 Neighbor Discovery ---"
ndp -a 2>/dev/null
echo ""

echo "--- IPv6 Routing Table ---"
netstat -rn -f inet6
echo ""

echo "--- Network Time Synchronization ---"
systemsetup -getusingnetworktime 2>/dev/null
systemsetup -getnetworktimeserver 2>/dev/null
echo ""

echo "--- NTP Activity ---"
log show --predicate 'process == "ntpd" OR eventMessage CONTAINS "NTP"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Network Reachability ---"
log show --predicate 'subsystem == "com.apple.network.reachability"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Network Quality of Service ---"
log show --predicate 'subsystem CONTAINS "qos" OR eventMessage CONTAINS "QoS"' --last 7d 2>/dev/null | tail -300
echo ""

echo ""
echo "========================================="
echo "Script 1 Complete: $(date)"
echo "========================================="
echo ""