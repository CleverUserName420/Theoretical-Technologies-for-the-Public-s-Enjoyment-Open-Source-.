#!/bin/bash

# Script 5: Platform & Protocol Specific Analysis
# Covers: macOS-specific behaviors, spoofing, enterprise attacks, resource exploitation, emerging tech, physical layer

echo "========================================="
echo "SCRIPT 5: Platform & Protocol Specific Analysis"
echo "Started: $(date)"
echo "========================================="
echo ""

# ============================================================================
# macOS SPECIFIC WIFI BEHAVIORS
# ============================================================================

echo "=== macOS SPECIFIC WIFI BEHAVIORS ==="
echo ""

echo "--- AWDL Interface Status ---"
ifconfig awdl0 2>/dev/null
echo ""

echo "--- AWDL Interface Statistics ---"
netstat -I awdl0 -b 2>/dev/null
echo ""

echo "--- AWDL Activity Logs (7 Days) ---"
log show --predicate 'subsystem CONTAINS "awdl"' --last 7d 2>/dev/null | tail -1000
echo ""

echo "--- AWDL Peer Discovery ---"
log show --predicate 'subsystem CONTAINS "awdl" AND eventMessage CONTAINS "peer"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- AWDL State Changes ---"
log show --predicate 'subsystem CONTAINS "awdl" AND eventMessage CONTAINS "state"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- CoreWLAN Preferences ---"
if [ -f "$HOME/Library/Preferences/com.apple.wifi.plist" ]; then
    plutil -p "$HOME/Library/Preferences/com.apple.wifi.plist" 2>/dev/null
fi
echo ""

echo "--- Airport Preferences ---"
if [ -f "/Library/Preferences/SystemConfiguration/com.apple.airport.preferences.plist" ]; then
    plutil -p "/Library/Preferences/SystemConfiguration/com.apple.airport.preferences.plist" 2>/dev/null | head -500
fi
echo ""

echo "--- NetworkExtension Configurations ---"
find ~/Library/Preferences /Library/Preferences -name "*networkextension*" -o -name "*NetworkExtension*" 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- Network Extension Activity ---"
log show --predicate 'subsystem == "com.apple.networkextension"' --last 7d 2>/dev/null | tail -1000
echo ""

echo "--- iCloud Private Relay Status ---"
log show --predicate 'subsystem CONTAINS "privaterelay"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Private Relay Connections ---"
log show --predicate 'eventMessage CONTAINS "private relay" OR eventMessage CONTAINS "icloud relay"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- WiFi Assist Activity ---"
log show --predicate 'eventMessage CONTAINS "WiFi Assist" OR eventMessage CONTAINS "wifi assist"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- WiFi to Cellular Handoff ---"
log show --predicate 'eventMessage CONTAINS "handoff" AND eventMessage CONTAINS "cellular"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- Location Services via WiFi ---"
log show --predicate 'subsystem == "com.apple.locationd" AND eventMessage CONTAINS "wifi"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Continuity Services ---"
log show --predicate 'subsystem CONTAINS "continuity"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Handoff Activity ---"
log show --predicate 'subsystem CONTAINS "handoff"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Handoff App Launches ---"
log show --predicate 'subsystem CONTAINS "handoff" AND eventMessage CONTAINS "launch"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- Universal Clipboard Events ---"
log show --predicate 'subsystem CONTAINS "universalclipboard" OR subsystem CONTAINS "clipboard"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Clipboard Sync Activity ---"
log show --predicate 'eventMessage CONTAINS "clipboard" AND eventMessage CONTAINS "sync"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- AirPlay Activity ---"
log show --predicate 'subsystem CONTAINS "airplay"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- AirPlay Mirroring ---"
log show --predicate 'subsystem CONTAINS "airplay" AND eventMessage CONTAINS "mirror"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- Sidecar Sessions ---"
log show --predicate 'subsystem CONTAINS "sidecar"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Sidecar Connections ---"
log show --predicate 'subsystem CONTAINS "sidecar" AND eventMessage CONTAINS "connect"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- Find My Network ---"
log show --predicate 'subsystem CONTAINS "findmy"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Find My Beaconing ---"
log show --predicate 'subsystem CONTAINS "findmy" AND eventMessage CONTAINS "beacon"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Find My Location Updates ---"
log show --predicate 'subsystem CONTAINS "findmy" AND eventMessage CONTAINS "location"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Network Framework Usage ---"
lsof 2>/dev/null | grep -i "network.framework" | head -200
echo ""

echo "--- Network Framework Logs ---"
log show --predicate 'subsystem CONTAINS "com.apple.network"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- NEHelper Activity ---"
log show --predicate 'process == "nehelper" OR process == "nesessionmanager"' --last 7d 2>/dev/null | tail -500
echo ""

# ============================================================================
# WIFI SPOOFING AND INTERCEPTION
# ============================================================================

echo "=== WIFI SPOOFING AND INTERCEPTION ==="
echo ""

echo "--- Current MAC Address (en0) ---"
ifconfig en0 | grep ether
echo ""

echo "--- Current MAC Address (en1) ---"
ifconfig en1 | grep ether 2>/dev/null
echo ""

echo "--- MAC Address Changes ---"
log show --predicate 'eventMessage CONTAINS "MAC" OR eventMessage CONTAINS "hardware address"' --last 30d 2>/dev/null | tail -500
echo ""

echo "--- MAC Address Spoofing Detection ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "MAC address"' --last 30d 2>/dev/null | tail -300
echo ""

echo "--- Hardware UUID ---"
system_profiler SPAirPortDataType | grep -i "hardware uuid"
echo ""

echo "--- Network Hardware Information ---"
networksetup -listallhardwareports
echo ""

echo "--- SSL/TLS Interception Indicators ---"
security dump-keychain 2>/dev/null | grep -iE "mitm|intercept|proxy" | head -100
echo ""

echo "--- Untrusted Certificates ---"
security dump-keychain 2>/dev/null | grep -B10 -A10 "untrusted"
echo ""

echo "--- Certificate Trust Modifications ---"
security dump-trust-settings 2>/dev/null | head -500
echo ""

echo "--- Custom Root CAs ---"
security find-certificate -a /Library/Keychains/System.keychain 2>/dev/null | grep -E "labl|issu" | head -500
echo ""

echo "--- Self-Signed Certificates ---"
security find-certificate -a 2>/dev/null | grep -B5 "self signed"
echo ""

echo "--- Certificate Installation Events ---"
log show --predicate 'eventMessage CONTAINS "certificate" AND eventMessage CONTAINS "install"' --last 30d 2>/dev/null | tail -300
echo ""

echo "--- Evil Twin Detection (Duplicate BSSIDs) ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "BSSID"' --last 7d 2>/dev/null | awk '{print $NF}' | grep -E "[0-9a-f:]{17}" | sort | uniq -d
echo ""

echo "--- Unexpected Network Changes ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "unexpected"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Network Authentication Failures ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "auth" AND eventMessage CONTAINS "fail"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- TLS/SSL Errors ---"
log show --predicate 'eventMessage CONTAINS "SSL" OR eventMessage CONTAINS "TLS"' --last 7d 2>/dev/null | grep -i error | tail -500
echo ""

echo "--- Certificate Validation Failures ---"
log show --predicate 'subsystem == "com.apple.securityd" AND eventMessage CONTAINS "certificate" AND eventMessage CONTAINS "fail"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- MITM Detection ---"
log show --predicate 'eventMessage CONTAINS "man-in-the-middle" OR eventMessage CONTAINS "MITM"' --last 30d 2>/dev/null | tail -200
echo ""

# ============================================================================
# ENTERPRISE WIFI ATTACKS
# ============================================================================

echo "=== ENTERPRISE WIFI ATTACKS ==="
echo ""

echo "--- 802.1X Configurations ---"
security dump-keychain 2>/dev/null | grep -iE "802\.1x|eap|radius" | head -500
echo ""

echo "--- 802.1X Activity ---"
log show --predicate 'eventMessage CONTAINS "802.1X"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- EAP Methods ---"
log show --predicate 'eventMessage CONTAINS "EAP"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- EAP-TLS Activity ---"
log show --predicate 'eventMessage CONTAINS "EAP-TLS"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- PEAP Activity ---"
log show --predicate 'eventMessage CONTAINS "PEAP"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- RADIUS Authentication ---"
log show --predicate 'eventMessage CONTAINS "RADIUS"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- RADIUS Server Communication ---"
lsof -i :1812 -i :1813 2>/dev/null
echo ""

echo "--- Enterprise WiFi Profiles ---"
find /Library/Preferences/SystemConfiguration -name "*eapolclient*" -o -name "*8021x*" -o -name "*EAP*" 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- EAPoL Client Configuration ---"
if [ -f "/Library/Preferences/SystemConfiguration/com.apple.eapolclient.configuration.plist" ]; then
    plutil -p "/Library/Preferences/SystemConfiguration/com.apple.eapolclient.configuration.plist" 2>/dev/null
fi
echo ""

echo "--- Certificate-Based Authentication ---"
security find-identity -v 2>/dev/null
echo ""

echo "--- Identity Certificates ---"
security find-identity -v -p sslclient 2>/dev/null
echo ""

echo "--- Client Certificates ---"
security find-certificate -a -c "client" 2>/dev/null | grep -E "labl|issu|subj"
echo ""

echo "--- NAC Bypass Indicators ---"
log show --predicate 'eventMessage CONTAINS "NAC" OR eventMessage CONTAINS "posture" OR eventMessage CONTAINS "compliance"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- MDM Profiles ---"
profiles -P 2>/dev/null
echo ""

echo "--- MDM Profile Details ---"
profiles list 2>/dev/null
echo ""

echo "--- Configuration Profiles ---"
profiles show 2>/dev/null
echo ""

echo "--- MDM Enrollment ---"
log show --predicate 'eventMessage CONTAINS "MDM" OR eventMessage CONTAINS "enrollment"' --last 30d 2>/dev/null | tail -500
echo ""

echo "--- Enterprise VPN Profiles ---"
find /Library/Preferences/SystemConfiguration -name "*vpn*" 2>/dev/null -exec grep -l "enterprise\|company\|corp" {} \;
echo ""

echo "--- Corporate Proxy Settings ---"
networksetup -listallnetworkservices 2>/dev/null | while read service; do
    proxy_info=$(networksetup -getwebproxy "$service" 2>/dev/null)
    if echo "$proxy_info" | grep -q "Enabled: Yes"; then
        echo "Service: $service"
        echo "$proxy_info"
        echo ""
    fi
done
echo ""


# ============================================================================
# EMERGING WIFI TECHNOLOGIES
# ============================================================================

echo "=== EMERGING WIFI TECHNOLOGIES ==="
echo ""

echo "--- WiFi 6/6E Support ---"
system_profiler SPAirPortDataType | grep -iE "wifi.*6|802\.11ax|6.*ghz"
echo ""

echo "--- WiFi 6 Activity ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "802.11ax"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- WPA3 Usage ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "WPA3"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- WPA3 Transition Mode ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "WPA3-transition"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- SAE (Simultaneous Authentication of Equals) ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "SAE"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- 6GHz Band Activity ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "6GHz"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Channel Width Detection ---"
/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport -I 2>/dev/null | grep -i "channel"
echo ""

echo "--- WiFi Sensing/Radar ---"
log show --predicate 'eventMessage CONTAINS "sensing" OR eventMessage CONTAINS "radar" OR eventMessage CONTAINS "motion"' --last 7d 2>/dev/null | grep -i wifi | tail -200
echo ""

echo "--- OWE (Opportunistic Wireless Encryption) ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "OWE"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- Enhanced Open ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "enhanced open"' --last 7d 2>/dev/null | tail -200
echo ""

# ============================================================================
# PHYSICAL LAYER ATTACKS
# ============================================================================

echo "=== PHYSICAL LAYER ATTACKS ==="
echo ""

echo "--- Signal Strength ---"
/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport -I 2>/dev/null | grep -iE "rssi|noise|signal|rate"
echo ""

echo "--- Current Channel ---"
/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport -I 2>/dev/null | grep -i "channel"
echo ""

echo "--- Signal Quality Metrics ---"
/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport -I 2>/dev/null
echo ""

echo "--- Interference Detection ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "interference"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Channel Interference ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "channel" AND eventMessage CONTAINS "busy"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- Jamming Indicators ---"
log show --predicate 'subsystem == "com.apple.wifi" AND (eventMessage CONTAINS "jam" OR eventMessage CONTAINS "blocked" OR eventMessage CONTAINS "unable")' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Deauthentication Frequency (24h) ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "deauth"' --last 24h 2>/dev/null | wc -l
echo ""

echo "--- Deauthentication Events ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "deauth"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Excessive Disconnections ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "disconnect"' --last 24h 2>/dev/null | wc -l
echo ""

echo "--- Channel Hopping ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "channel"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Beacon Loss ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "beacon" AND eventMessage CONTAINS "loss"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Link Quality ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "link quality"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Retry Rate ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "retry"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Frame Errors ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "frame" AND eventMessage CONTAINS "error"' --last 7d 2>/dev/null | tail -300
echo ""

# ============================================================================
# MALICIOUS NETWORK PROCESSES
# ============================================================================

echo "=== MALICIOUS NETWORK PROCESSES ==="
echo ""

echo "--- Suspicious Process Names ---"
ps aux | grep -iE "bot|rat|backdoor|payload|shell|cmd|reverse|bind|exploit|dropper|loader" | grep -v grep
echo ""

echo "--- Processes with Network Activity ---"
lsof -i -n -P 2>/dev/null | awk '{print $1}' | sort -u
echo ""

echo "--- Network Processes Details ---"
for proc in $(lsof -i -n -P 2>/dev/null | awk '{print $1}' | sort -u); do
    echo "=== $proc ==="
    ps aux | grep "^[^ ]*  *[^ ]*  *[^ ]*  *[^ ]*  *[^ ]*  *[^ ]*  *[^ ]*  *[^ ]*  *[^ ]*  *[^ ]*  *.*$proc" | head -5
    echo ""
done | head -500
echo ""

echo "--- Unsigned Network Processes ---"
lsof -i -n -P 2>/dev/null | awk '{print $1}' | sort -u | while read proc; do
    proc_path=$(ps aux | grep "$proc" | grep -v grep | awk '{for(i=11;i<=NF;i++) printf $i" "; print ""}' | head -1 | awk '{print $1}')
    if [ -f "$proc_path" ]; then
        if codesign -v "$proc_path" 2>&1 | grep -q "invalid"; then
            echo "UNSIGNED: $proc ($proc_path)"
        fi
    fi
done
echo ""

echo "--- Hidden Processes ---"
ps aux | awk '$11 ~ /^\./' | grep -v grep
echo ""

echo "--- Processes from Temp Directories ---"
ps aux | grep -E "/tmp/|/var/tmp/|/private/tmp/" | grep -v grep
echo ""

echo "--- Processes from User Directories ---"
ps aux | grep -E "/Users/.*/\." | grep -v "Library\|Application Support" | grep -v grep
echo ""

echo "--- Suspicious Parent-Child Relationships ---"
ps auxww -o pid,ppid,user,command | grep -iE "bash.*curl|bash.*wget|python.*http|perl.*socket"
echo ""

echo "--- Network Activity from Scripts ---"
lsof -i -n -P 2>/dev/null | grep -iE "python|perl|ruby|php|bash|sh"
echo ""

# ============================================================================
# PROCESS AND MEMORY ANALYSIS
# ============================================================================

echo "=== PROCESS AND MEMORY ANALYSIS ==="
echo ""

echo "--- All Running Processes ---"
ps aux
echo ""

echo "--- Process Tree ---"
ps auxww -o pid,ppid,user,%cpu,%mem,command
echo ""

echo "--- Long-Running Processes ---"
ps auxww -o etime,pid,command | sort -k1 -rn | head -50
echo ""

echo "--- Processes with Open Files ---"
lsof 2>/dev/null | head -2000
echo ""

echo "--- Virtual Memory Statistics ---"
vm_stat
echo ""

echo "--- Memory Pressure ---"
memory_pressure
echo ""

echo "--- Swap Usage ---"
sysctl vm.swapusage
echo ""

echo "--- Page Faults ---"
vm_stat | grep -i "page.*fault"
echo ""

echo "--- Process Memory Maps ---"
for pid in $(ps aux | grep -iE "network|wifi|vpn" | grep -v grep | awk '{print $2}'); do
    echo "=== PID $pid ==="
    vmmap $pid 2>/dev/null | head -100
    echo ""
done | head -1000
echo ""

# ============================================================================
# FILE SYSTEM FORENSICS
# ============================================================================

echo "=== FILE SYSTEM FORENSICS ==="
echo ""

echo "--- Recently Modified Files (Library) ---"
find ~/Library -type f -mtime -7 2>/dev/null -exec ls -la {} \; | head -1000
echo ""

echo "--- Recently Accessed Network Preferences ---"
find ~/Library/Preferences /Library/Preferences -type f -atime -7 -name "*network*" -o -name "*wifi*" -o -name "*airport*" 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- Suspicious Hidden Files (30 Days) ---"
find ~ -name ".*" -type f -mtime -30 2>/dev/null | head -500
echo ""

echo "--- Recently Created Files ---"
find ~ -type f -mtime -7 2>/dev/null -exec ls -la {} \; | head -500
echo ""

echo "--- Large Files in Temp ---"
find /tmp /var/tmp -type f -size +10M 2>/dev/null -exec ls -lh {} \;
echo ""

echo "--- Binary Files in User Directories ---"
find ~ -type f \( -name "*.bin" -o -name "*.dat" -o -name "*.dylib" -o -name "*.so" \) 2>/dev/null | grep -v Library | head -200
echo ""

echo "--- Script Files (Recent) ---"
find ~ -type f \( -name "*.sh" -o -name "*.py" -o -name "*.pl" -o -name "*.rb" -o -name "*.js" \) -mtime -30 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- Executable Files (Recent) ---"
find ~ -type f -perm +111 -mtime -30 2>/dev/null -exec ls -la {} \; | head -200
echo ""

echo ""
echo "========================================="
echo "Script 5 Complete: $(date)"
echo "========================================="
echo ""


# ============================================================================
# POWER AND RESOURCE EXPLOITATION
# ============================================================================

echo "=== POWER AND RESOURCE EXPLOITATION ==="
echo ""

echo "--- Battery Status ---"
pmset -g batt
echo ""

echo "--- Power Management Settings ---"
pmset -g
echo ""

echo "--- AC Power Settings ---"
pmset -g ac
echo ""

echo "--- Battery Power Settings ---"
pmset -g batt
echo ""

echo "--- System Power State ---"
pmset -g ps
echo ""

echo "--- Assertions ---"
pmset -g assertions
echo ""

echo "--- Energy Impact (Top Processes) ---"
ps aux -m | head -100
echo ""

echo "--- CPU Usage (Top 30) ---"
ps aux | sort -k3 -rn | head -30
echo ""

echo "--- Memory Usage (Top 30) ---"
ps aux | sort -k4 -rn | head -30
echo ""

echo "--- Network Process CPU Usage ---"
ps aux | grep -iE "network|wifi|airport|vpn|dns" | sort -k3 -rn | head -30
echo ""

echo "--- Network Process Memory Usage ---"
ps aux | grep -iE "network|wifi|airport|vpn|dns" | sort -k4 -rn | head -30
echo ""

echo "--- WiFi Scanning Frequency (24h) ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "scan"' --last 24h 2>/dev/null | wc -l
echo ""

echo "--- WiFi Scan Activity ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "scan"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Network I/O Statistics ---"
iostat -w 1 -c 5 2>/dev/null
echo ""

echo "--- Disk I/O by Process ---"
iotop -P 2>/dev/null | head -50
echo ""

echo "--- Thermal State ---"
pmset -g therm
echo ""

echo "--- Thermal Pressure ---"
log show --predicate 'eventMessage CONTAINS "thermal" OR eventMessage CONTAINS "temperature"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- CPU Temperature ---"
sysctl machdep.xcpm.cpu_thermal_level 2>/dev/null
echo ""

echo "--- Fan Speed ---"
sysctl machdep.xcpm.fan_speed 2>/dev/null
echo ""

echo "--- Sleep/Wake History ---"
pmset -g log | grep -E "Sleep|Wake" | tail -100
echo ""

echo "--- Power Events ---"
log show --predicate 'subsystem == "com.apple.powermanagement"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Battery Drain Rate ---"
pmset -g rawlog | tail -100
echo ""
