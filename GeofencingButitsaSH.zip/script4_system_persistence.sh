#!/bin/bash

# Script 4: System & Persistence Analysis  
# Covers: Persistence mechanisms, temporal triggers, chipset attacks, reconnaissance, firmware, forensics

echo "========================================="
echo "SCRIPT 4: System & Persistence Analysis"
echo "Started: $(date)"
echo "========================================="
echo ""

# ============================================================================
# PERSISTENCE AND STEALTH
# ============================================================================

echo "=== PERSISTENCE AND STEALTH ==="
echo ""

echo "--- WiFi Kernel Extensions ---"
find /System/Library/Extensions -name "*[Ww]i[Ff]i*" -o -name "*[Aa]irport*" 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- Network Kernel Extensions ---"
find /System/Library/Extensions -name "*[Nn]etwork*" 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- IO80211 Family ---"
ls -laR /System/Library/Extensions/IO80211Family.kext/ 2>/dev/null
echo ""

echo "--- Loaded WiFi KEXTs ---"
kextstat | grep -iE "wifi|airport|80211"
echo ""

echo "--- Loaded Network KEXTs ---"
kextstat | grep -iE "network|ethernet|en[0-9]"
echo ""

echo "--- All Loaded Kernel Extensions ---"
kextstat
echo ""

echo "--- Third-Party KEXTs ---"
kextstat | grep -v "com.apple"
echo ""

echo "--- KEXT Load History ---"
log show --predicate 'eventMessage CONTAINS "kext" OR eventMessage CONTAINS "kernel extension"' --last 30d 2>/dev/null | tail -1000
echo ""

echo "--- Launch Daemons (All) ---"
ls -la /Library/LaunchDaemons/ 2>/dev/null
echo ""

echo "--- Launch Daemons (Network-Related) ---"
find /Library/LaunchDaemons -type f 2>/dev/null -exec grep -l -iE "network|wifi|airport|vpn|tunnel" {} \;
echo ""

echo "--- Launch Daemon Contents (Network) ---"
for daemon in /Library/LaunchDaemons/*; do
    if [ -f "$daemon" ]; then
        if grep -q -iE "network|wifi|airport|vpn" "$daemon" 2>/dev/null; then
            echo "=== $daemon ==="
            cat "$daemon"
            echo ""
        fi
    fi
done
echo ""

echo "--- Launch Agents (System) ---"
ls -la /Library/LaunchAgents/ 2>/dev/null
echo ""

echo "--- Launch Agents (User) ---"
ls -la ~/Library/LaunchAgents/ 2>/dev/null
echo ""

echo "--- Launch Agent Contents (Network) ---"
for agent in /Library/LaunchAgents/* ~/Library/LaunchAgents/*; do
    if [ -f "$agent" ]; then
        if grep -q -iE "network|wifi|airport|vpn" "$agent" 2>/dev/null; then
            echo "=== $agent ==="
            cat "$agent"
            echo ""
        fi
    fi
done
echo ""

echo "--- Running Launch Services ---"
launchctl list
echo ""

echo "--- Network-Related Launch Services ---"
launchctl list | grep -iE "network|wifi|airport|vpn"
echo ""

echo "--- System Launch Daemons ---"
ls -la /System/Library/LaunchDaemons/ 2>/dev/null | grep -iE "network|wifi"
echo ""

echo "--- System Launch Agents ---"
ls -la /System/Library/LaunchAgents/ 2>/dev/null | grep -iE "network|wifi"
echo ""

echo "--- System Extensions Directory ---"
ls -laR /Library/SystemExtensions/ 2>/dev/null
echo ""

echo "--- Approved System Extensions ---"
systemextensionsctl list 2>/dev/null
echo ""

echo "--- StartupItems (Legacy) ---"
ls -laR /Library/StartupItems /System/Library/StartupItems 2>/dev/null
echo ""

echo "--- Periodic Scripts ---"
ls -la /etc/periodic/daily/ 2>/dev/null
ls -la /etc/periodic/weekly/ 2>/dev/null
ls -la /etc/periodic/monthly/ 2>/dev/null
echo ""

echo "--- Periodic Script Contents ---"
for script in /etc/periodic/daily/* /etc/periodic/weekly/* /etc/periodic/monthly/*; do
    if [ -f "$script" ]; then
        echo "=== $script ==="
        cat "$script" 2>/dev/null | head -50
        echo ""
    fi
done
echo ""

echo "--- rc.common Scripts ---"
if [ -f "/etc/rc.common" ]; then
    cat /etc/rc.common
fi
echo ""

echo "--- Login Items ---"
osascript -e 'tell application "System Events" to get the name of every login item' 2>/dev/null
echo ""

echo "--- Login Hooks ---"
defaults read com.apple.loginwindow LoginHook 2>/dev/null
defaults read com.apple.loginwindow LogoutHook 2>/dev/null
echo ""

echo "--- Persistent Applications ---"
log show --predicate 'eventMessage CONTAINS "persistent" OR eventMessage CONTAINS "always run"' --last 30d 2>/dev/null | tail -300
echo ""

# ============================================================================
# TEMPORAL AND TRIGGER BEHAVIORS
# ============================================================================

echo "=== TEMPORAL AND TRIGGER BEHAVIORS ==="
echo ""

echo "--- User Cron Jobs ---"
crontab -l 2>/dev/null
echo ""

echo "--- Root Cron Jobs ---"
sudo crontab -l 2>/dev/null
echo ""

echo "--- System Cron ---"
cat /etc/crontab 2>/dev/null
echo ""

echo "--- Cron Directory ---"
ls -la /usr/lib/cron/ 2>/dev/null
echo ""

echo "--- Scheduled Launch Items ---"
find /Library/LaunchAgents /Library/LaunchDaemons ~/Library/LaunchAgents -type f 2>/dev/null -exec grep -l "StartCalendarInterval\|StartInterval" {} \;
echo ""

echo "--- Timed Launch Items ---"
for item in /Library/LaunchAgents/* /Library/LaunchDaemons/* ~/Library/LaunchAgents/*; do
    if [ -f "$item" ]; then
        if grep -q "StartCalendarInterval\|StartInterval" "$item" 2>/dev/null; then
            echo "=== $item ==="
            grep -A5 "StartCalendarInterval\|StartInterval" "$item"
            echo ""
        fi
    fi
done
echo ""

echo "--- Path-Watching Launch Items ---"
for item in /Library/LaunchAgents/* /Library/LaunchDaemons/* ~/Library/LaunchAgents/*; do
    if [ -f "$item" ]; then
        if grep -q "WatchPaths\|QueueDirectories" "$item" 2>/dev/null; then
            echo "=== $item ==="
            cat "$item"
            echo ""
        fi
    fi
done
echo ""

echo "--- Power Management Events (7 Days) ---"
log show --predicate 'eventMessage CONTAINS "wake" OR eventMessage CONTAINS "sleep" OR eventMessage CONTAINS "power"' --last 7d 2>/dev/null | tail -1000
echo ""

echo "--- Network State Change Events ---"
log show --predicate 'eventMessage CONTAINS "network change" OR eventMessage CONTAINS "link status" OR eventMessage CONTAINS "interface.*up\|down"' --last 7d 2>/dev/null | tail -1000
echo ""

echo "--- WiFi Association Events ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "assoc"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- WiFi Join Events ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "join"' --last 30d 2>/dev/null | tail -500
echo ""

echo "--- Network Transition Triggers ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "transition"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Time-Based Network Activity ---"
log show --predicate 'subsystem == "com.apple.networkd"' --last 24h 2>/dev/null | awk '{print $1}' | cut -d: -f1 | sort | uniq -c
echo ""

echo "--- Network Activity by Hour ---"
log show --predicate 'subsystem == "com.apple.networkd"' --last 7d 2>/dev/null | awk '{print $2}' | cut -d: -f1 | sort | uniq -c
echo ""

echo "--- At Jobs ---"
atq 2>/dev/null
echo ""

echo "--- Calendar-Based Triggers ---"
log show --predicate 'eventMessage CONTAINS "calendar" OR eventMessage CONTAINS "schedule"' --last 7d 2>/dev/null | grep -iE "network|wifi" | tail -300
echo ""

# ============================================================================
# CHIPSET AND DRIVER LEVEL ATTACKS
# ============================================================================

echo "=== CHIPSET AND DRIVER LEVEL ATTACKS ==="
echo ""

echo "--- WiFi Chipset Information ---"
system_profiler SPAirPortDataType
echo ""

echo "--- Network Hardware Details ---"
system_profiler SPNetworkDataType
echo ""

echo "--- PCI Devices ---"
system_profiler SPPCIDataType
echo ""

echo "--- USB Devices (WiFi Adapters) ---"
system_profiler SPUSBDataType | grep -A 10 -iE "wifi|wireless|802\.11|network"
echo ""

echo "--- IO80211 Family Details ---"
kextstat -l -b com.apple.iokit.IO80211Family 2>/dev/null
echo ""

echo "--- Broadcom KEXTs ---"
kextstat | grep -i broadcom
echo ""

echo "--- Broadcom Extensions ---"
find /System/Library/Extensions -name "*Broadcom*" 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- Intel WiFi KEXTs ---"
kextstat | grep -i "intel.*wifi\|intel.*wireless"
echo ""

echo "--- Intel Extensions ---"
find /System/Library/Extensions -name "*Intel*" 2>/dev/null | grep -iE "wifi|wireless|network"
echo ""

echo "--- Atheros KEXTs ---"
kextstat | grep -i atheros
echo ""

echo "--- Atheros Extensions ---"
find /System/Library/Extensions -name "*Atheros*" 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- WiFi Firmware Location ---"
ls -laR /usr/share/firmware/ 2>/dev/null
echo ""

echo "--- System Firmware ---"
ls -laR /System/Library/Firmware/ 2>/dev/null | head -200
echo ""

echo "--- Driver Diagnostics ---"
log show --predicate 'subsystem == "com.apple.iokit"' --last 7d 2>/dev/null | grep -iE "wifi|airport|80211|network" | tail -1000
echo ""

echo "--- IO Registry WiFi Devices ---"
ioreg -l | grep -iE "wifi|airport|80211|broadcom|atheros" | head -500
echo ""

echo "--- IO Registry Network Interfaces ---"
ioreg -l -n "IONetworkInterface" 2>/dev/null
echo ""

echo "--- IO Registry WiFi Properties ---"
ioreg -l -n "AirPort" 2>/dev/null
echo ""

echo "--- Driver Load Errors ---"
log show --predicate 'subsystem == "com.apple.iokit" AND eventMessage CONTAINS "error"' --last 7d 2>/dev/null | grep -iE "wifi|network|driver" | tail -500
echo ""

echo "--- Kernel Panic Logs ---"
ls -la /Library/Logs/DiagnosticReports/Kernel* 2>/dev/null
echo ""

echo "--- Recent Kernel Panics (30 Days) ---"
find /Library/Logs/DiagnosticReports -name "Kernel*" -mtime -30 -exec ls -la {} \; 2>/dev/null
echo ""

echo "--- Kernel Panic Content (Most Recent) ---"
find /Library/Logs/DiagnosticReports -name "Kernel*" -type f 2>/dev/null | head -1 | xargs cat
echo ""

echo "--- DMA Configuration ---"
ioreg -l | grep -i "dma" | head -100
echo ""

echo "--- WiFi Firmware Version ---"
system_profiler SPAirPortDataType | grep -i "firmware"
echo ""

echo "--- Driver Versions ---"
kextstat | grep -iE "wifi|airport|network" | awk '{print $1, $2, $6}'
echo ""

# ============================================================================
# RECONNAISSANCE AND PROFILING
# ============================================================================

echo "=== RECONNAISSANCE AND PROFILING ==="
echo ""

echo "--- WiFi Connection History (30 Days) ---"
log show --predicate 'subsystem == "com.apple.wifi" AND (eventMessage CONTAINS "join" OR eventMessage CONTAINS "connect")' --last 30d 2>/dev/null | tail -1000
echo ""

echo "--- Network SSID History ---"
log show --predicate 'subsystem == "com.apple.wifi"' --last 30d 2>/dev/null | grep -oE 'SSID.*' | sort -u | head -200
echo ""

echo "--- BSSID History ---"
log show --predicate 'subsystem == "com.apple.wifi"' --last 30d 2>/dev/null | grep -oE 'BSSID.*[0-9a-f:]{17}' | sort -u | head -200
echo ""

echo "--- Location History Caches ---"
find ~/Library/Caches -name "*location*" -o -name "*gps*" -o -name "*map*" 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- Significant Locations Database ---"
if [ -f "$HOME/Library/Caches/com.apple.routined/Local.sqlite" ]; then
    ls -la "$HOME/Library/Caches/com.apple.routined/"
fi
echo ""

echo "--- Route Daemon Cache ---"
ls -laR "$HOME/Library/Caches/com.apple.routined/" 2>/dev/null
echo ""

echo "--- Travel Pattern Analysis ---"
log show --predicate 'subsystem == "com.apple.routined"' --last 30d 2>/dev/null | tail -500
echo ""

echo "--- Frequent Locations ---"
log show --predicate 'subsystem == "com.apple.routined" AND eventMessage CONTAINS "frequent"' --last 30d 2>/dev/null | tail -300
echo ""

echo "--- Corporate Network Detection ---"
security dump-keychain 2>/dev/null | grep -iE "corp|enterprise|company|work|office" | head -200
echo ""

echo "--- Enterprise WiFi Networks ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "802.1X"' --last 30d 2>/dev/null | tail -500
echo ""

echo "--- VPN Usage Patterns ---"
log show --predicate 'eventMessage CONTAINS "VPN"' --last 30d 2>/dev/null | tail -500
echo ""

echo "--- Network Profile Analysis ---"
networksetup -listpreferredwirelessnetworks en0 2>/dev/null
echo ""

echo "--- Network Naming Patterns ---"
networksetup -listpreferredwirelessnetworks en0 2>/dev/null | awk '{print length, $0}' | sort -n
echo ""

echo "--- Frequent Network Transitions ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "transition"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Roaming Behavior ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "roam"' --last 30d 2>/dev/null | tail -500
echo ""

echo "--- Device Mobility Patterns ---"
log show --predicate 'subsystem == "com.apple.locationd" AND eventMessage CONTAINS "movement"' --last 30d 2>/dev/null | tail -300
echo ""

# ============================================================================
# FIRMWARE AND BOOT LEVEL
# ============================================================================

echo "=== FIRMWARE AND BOOT LEVEL ==="
echo ""

echo "--- EFI/Firmware Version ---"
system_profiler SPSoftwareDataType | grep -iE "boot|firmware|efi"
echo ""

echo "--- Boot ROM Version ---"
system_profiler SPHardwareDataType | grep -i "boot rom"
echo ""

echo "--- SMC Version ---"
system_profiler SPHardwareDataType | grep -i "smc"
echo ""

echo "--- Secure Boot Status ---"
csrutil status 2>/dev/null
echo ""

echo "--- System Integrity Protection ---"
csrutil status 2>/dev/null
echo ""

echo "--- Authenticated Root Status ---"
csrutil authenticated-root status 2>/dev/null
echo ""

echo "--- FileVault Status ---"
fdesetup status 2>/dev/null
echo ""

echo "--- Gatekeeper Status ---"
spctl --status 2>/dev/null
echo ""

echo "--- Gatekeeper Assessment ---"
spctl --assess --verbose /Applications/*.app 2>/dev/null | head -50
echo ""

echo "--- NVRAM Variables ---"
nvram -p 2>/dev/null | head -200
echo ""

echo "--- Boot Arguments ---"
nvram boot-args 2>/dev/null
echo ""

echo "--- Recovery Lock Status ---"
if command -v firmwarepasswd >/dev/null 2>&1; then
    firmwarepasswd -check 2>/dev/null
fi
echo ""

echo "--- EFI Login Items ---"
find /Library/StartupItems /System/Library/StartupItems -type f 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- Boot Cache ---"
ls -la /var/db/BootCache* 2>/dev/null
echo ""

echo "--- Boot Plist ---"
if [ -f "/Library/Preferences/SystemConfiguration/com.apple.Boot.plist" ]; then
    plutil -p "/Library/Preferences/SystemConfiguration/com.apple.Boot.plist" 2>/dev/null
fi
echo ""

echo "--- Kernel Extensions at Boot ---"
kextstat | head -100
echo ""

echo "--- Kernel Boot Messages ---"
log show --predicate 'messageType == 17' --last 30d 2>/dev/null | head -500
echo ""

echo "--- System Boot History ---"
log show --predicate 'eventMessage CONTAINS "boot" OR eventMessage CONTAINS "startup"' --last 30d 2>/dev/null | tail -500
echo ""

echo "--- Firmware Updates ---"
log show --predicate 'eventMessage CONTAINS "firmware" AND eventMessage CONTAINS "update"' --last 90d 2>/dev/null | tail -300
echo ""

echo "--- UEFI Logs ---"
log show --predicate 'subsystem CONTAINS "uefi" OR subsystem CONTAINS "efi"' --last 30d 2>/dev/null | tail -300
echo ""

# ============================================================================
# ADDITIONAL FORENSIC INDICATORS
# ============================================================================

echo "=== ADDITIONAL FORENSIC INDICATORS ==="
echo ""

echo "--- Modified System Binaries (30 Days) ---"
find /usr/bin /usr/sbin /bin /sbin -type f -mtime -30 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- Modified System Files (30 Days) ---"
find /System/Library -type f -mtime -30 2>/dev/null | head -500
echo ""

echo "--- Modified LaunchDaemons (30 Days) ---"
find /Library/LaunchDaemons -type f -mtime -30 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- Modified LaunchAgents (30 Days) ---"
find /Library/LaunchAgents ~/Library/LaunchAgents -type f -mtime -30 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- Recently Modified KEXTs ---"
find /System/Library/Extensions /Library/Extensions -type f -mtime -30 2>/dev/null | head -200
echo ""

echo "--- Suspicious File Locations ---"
find /tmp /var/tmp -type f -mtime -7 2>/dev/null -exec ls -la {} \; | head -200
echo ""

echo "--- Hidden Files (Recent) ---"
find ~ -name ".*" -type f -mtime -30 2>/dev/null | head -500
echo ""

echo "--- World-Writable Files ---"
find /Library /System/Library -type f -perm -002 2>/dev/null | head -200
echo ""

echo "--- SUID Files ---"
find /usr /Library -type f -perm -4000 2>/dev/null | head -100
echo ""

echo "--- SGID Files ---"
find /usr /Library -type f -perm -2000 2>/dev/null | head -100
echo ""

echo "--- Files with No Owner ---"
find / -nouser 2>/dev/null | head -100
echo ""

echo "--- Files with No Group ---"
find / -nogroup 2>/dev/null | head -100
echo ""

echo "--- Unsigned Applications ---"
find /Applications -name "*.app" -type d 2>/dev/null | while read app; do
    codesign -v "$app" 2>&1 | grep -q "invalid" && echo "UNSIGNED: $app"
done | head -50
echo ""

echo "--- Code Signature Violations ---"
log show --predicate 'eventMessage CONTAINS "signature" AND eventMessage CONTAINS "invalid"' --last 30d 2>/dev/null | tail -300
echo ""

echo "--- Gatekeeper Violations ---"
log show --predicate 'process == "syspolicyd" AND eventMessage CONTAINS "deny"' --last 30d 2>/dev/null | tail -300
echo ""

echo "--- Quarantine Events ---"
log show --predicate 'eventMessage CONTAINS "quarantine"' --last 30d 2>/dev/null | tail -500
echo ""

echo "--- System Log Errors ---"
log show --predicate 'messageType == 16' --last 7d 2>/dev/null | tail -1000
echo ""

echo "--- Crash Reports (User) ---"
ls -lat ~/Library/Logs/DiagnosticReports/ 2>/dev/null | head -100
echo ""

echo "--- Crash Reports (System) ---"
ls -lat /Library/Logs/DiagnosticReports/ 2>/dev/null | head -100
echo ""

echo "--- Recent Application Crashes ---"
find ~/Library/Logs/DiagnosticReports -name "*.crash" -mtime -7 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- Install History ---"
if [ -f "/Library/Receipts/InstallHistory.plist" ]; then
    plutil -p "/Library/Receipts/InstallHistory.plist" 2>/dev/null | tail -500
fi
echo ""

echo "--- Package Receipts ---"
ls -lat /var/db/receipts/ 2>/dev/null | head -100
echo ""

echo "--- System Update History ---"
softwareupdate --history 2>/dev/null
echo ""

echo ""
echo "========================================="
echo "Script 4 Complete: $(date)"
echo "========================================="
echo ""