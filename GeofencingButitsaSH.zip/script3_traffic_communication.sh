#!/bin/bash

# Script 3: Traffic & Communication Analysis
# Covers: Traffic obfuscation, covert channels, cross-device, C2 communication, tracking

echo "========================================="
echo "SCRIPT 3: Traffic & Communication Analysis"
echo "Started: $(date)"
echo "========================================="
echo ""

# ============================================================================
# NETWORK TRAFFIC EVASION AND OBFUSCATION
# ============================================================================

echo "=== NETWORK TRAFFIC EVASION AND OBFUSCATION ==="
echo ""

echo "--- All Network Connections ---"
lsof -i -n -P 2>/dev/null
echo ""

echo "--- Established TCP Connections ---"
lsof -i TCP -n -P 2>/dev/null | grep ESTABLISHED
echo ""

echo "--- Established UDP Connections ---"
lsof -i UDP -n -P 2>/dev/null
echo ""

echo "--- Listening Services ---"
lsof -i -n -P 2>/dev/null | grep LISTEN
echo ""

echo "--- Foreign Address Summary ---"
lsof -i -n -P 2>/dev/null | awk '{print $9}' | grep -E "^[0-9]" | cut -d: -f1 | sort | uniq -c | sort -rn
echo ""

echo "--- High Port Connections ---"
lsof -i -n -P 2>/dev/null | grep -E ":[8-9][0-9]{3}|:[1-6][0-9]{4}"
echo ""

echo "--- VPN Processes ---"
ps aux | grep -iE "vpn|openvpn|wireguard|nordvpn|expressvpn" | grep -v grep
echo ""

echo "--- Tunnel Processes ---"
ps aux | grep -iE "tunnel|ssh.*-[DLR]|autossh|stunnel" | grep -v grep
echo ""

echo "--- Tor Processes ---"
ps aux | grep -iE "^tor |torrc|/tor$" | grep -v grep
echo ""

echo "--- Tor Connections ---"
lsof -i :9050 -i :9051 -i :9150 2>/dev/null
echo ""

echo "--- I2P Processes ---"
ps aux | grep -i "i2p" | grep -v grep
echo ""

echo "--- Proxy Processes ---"
ps aux | grep -iE "proxy|squid|privoxy|tinyproxy|polipo" | grep -v grep
echo ""

echo "--- SOCKS Proxy Activity ---"
lsof -i -n -P 2>/dev/null | grep -E ":1080|:1081|:9050"
echo ""

echo "--- Packet Filter Status ---"
pfctl -s info 2>/dev/null
echo ""

echo "--- Packet Filter Rules ---"
pfctl -s rules 2>/dev/null
echo ""

echo "--- Packet Filter NAT Rules ---"
pfctl -s nat 2>/dev/null
echo ""

echo "--- Packet Filter States ---"
pfctl -s states 2>/dev/null | head -200
echo ""

echo "--- PF Configuration File ---"
if [ -f "/etc/pf.conf" ]; then
    cat /etc/pf.conf
fi
echo ""

echo "--- Application Firewall Status ---"
/usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate 2>/dev/null
echo ""

echo "--- Application Firewall Applications ---"
/usr/libexec/ApplicationFirewall/socketfilterfw --listapps 2>/dev/null
echo ""

echo "--- Application Firewall Logging ---"
/usr/libexec/ApplicationFirewall/socketfilterfw --getloggingmode 2>/dev/null
echo ""

echo "--- Stealth Mode ---"
/usr/libexec/ApplicationFirewall/socketfilterfw --getstealthmode 2>/dev/null
echo ""

echo "--- DNS Activity (7 Days) ---"
log show --predicate 'process == "mDNSResponder" OR process == "DNSResponder"' --last 7d 2>/dev/null | tail -2000
echo ""

echo "--- DNS-over-HTTPS Activity ---"
log show --predicate 'eventMessage CONTAINS "DoH" OR eventMessage CONTAINS "dns-over-https"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- DNS-over-TLS Activity ---"
log show --predicate 'eventMessage CONTAINS "DoT" OR eventMessage CONTAINS "dns-over-tls"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Cloudflare DNS Usage ---"
log show --predicate 'process == "mDNSResponder"' --last 7d 2>/dev/null | grep -E "1\.1\.1\.1|1\.0\.0\.1" | tail -200
echo ""

echo "--- Quad9 DNS Usage ---"
log show --predicate 'process == "mDNSResponder"' --last 7d 2>/dev/null | grep -E "9\.9\.9\.9" | tail -200
echo ""

echo "--- Google DNS Usage ---"
log show --predicate 'process == "mDNSResponder"' --last 7d 2>/dev/null | grep -E "8\.8\.8\.8|8\.8\.4\.4" | tail -200
echo ""

echo "--- Unusual DNS Queries ---"
log show --predicate 'process == "mDNSResponder"' --last 7d 2>/dev/null | grep -iE "\.onion|\.i2p|long.*query" | tail -500
echo ""

echo "--- DNS TXT Record Queries ---"
log show --predicate 'process == "mDNSResponder" AND eventMessage CONTAINS "TXT"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Network Extension Processes ---"
ps aux | grep -i "nesession\|neagent" | grep -v grep
echo ""

echo "--- Network Extension Logs ---"
log show --predicate 'subsystem == "com.apple.networkextension"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- VPN Configuration Files ---"
ls -la /Library/Preferences/SystemConfiguration/ 2>/dev/null | grep -i vpn
find /Library/Preferences/SystemConfiguration -name "*vpn*" -o -name "*VPN*" 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- IPSec Configuration ---"
if [ -f "/etc/ipsec.conf" ]; then
    cat /etc/ipsec.conf
fi
echo ""

echo "--- IPSec Activity ---"
log show --predicate 'eventMessage CONTAINS "IPSec" OR eventMessage CONTAINS "IKE"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Network Kernel Extensions ---"
kextstat | grep -iE "network|vpn|tunnel|tun|tap|pf"
echo ""

echo "--- TUN/TAP Interfaces ---"
ifconfig -a | grep -A5 -iE "tun|tap|utun"
echo ""

echo "--- UTUN Interface Details ---"
for iface in $(ifconfig -a | grep -o "utun[0-9]*"); do
    echo "=== $iface ==="
    ifconfig $iface
    echo ""
done
echo ""

echo "--- Protocol Mimicry Detection ---"
lsof -i -n -P 2>/dev/null | grep -E ":80|:443" | grep -v -E "Safari|Chrome|Firefox|curl|wget"
echo ""

echo "--- Encrypted Traffic Endpoints ---"
lsof -i -n -P 2>/dev/null | grep ":443"
echo ""

echo "--- Steganography Tools ---"
ps aux | grep -iE "steghide|outguess|stegano|covert" | grep -v grep
echo ""

echo "--- Traffic Shaping ---"
log show --predicate 'eventMessage CONTAINS "traffic shaping" OR eventMessage CONTAINS "bandwidth"' --last 7d 2>/dev/null | tail -200
echo ""

# ============================================================================
# COVERT CHANNELS AND EXFILTRATION
# ============================================================================

echo "=== COVERT CHANNELS AND EXFILTRATION ==="
echo ""

echo "--- Unusual Outbound Connections ---"
lsof -i -n -P 2>/dev/null | grep -v "localhost\|127\.0\.0\.1\|::1" | grep ESTABLISHED
echo ""

echo "--- Data Transfer by Process ---"
lsof -i -n -P 2>/dev/null | awk '{print $1}' | sort | uniq -c | sort -rn | head -30
echo ""

echo "--- High Volume Network Processes ---"
nettop -P -L 1 2>/dev/null | head -100
echo ""

echo "--- DNS Tunneling Indicators ---"
log show --predicate 'process == "mDNSResponder"' --last 7d 2>/dev/null | grep -E "TXT|NULL|CNAME|MX" | tail -500
echo ""

echo "--- Long DNS Queries ---"
log show --predicate 'process == "mDNSResponder"' --last 7d 2>/dev/null | grep -E ".{50,}" | tail -300
echo ""

echo "--- High Frequency DNS Queries ---"
log show --predicate 'process == "mDNSResponder"' --last 1d 2>/dev/null | awk '{print $NF}' | sort | uniq -c | sort -rn | head -50
echo ""

echo "--- ICMP Traffic ---"
ps aux | grep -iE "ping|icmp" | grep -v grep
echo ""

echo "--- ICMP Tunneling Tools ---"
ps aux | grep -iE "icmptunnel|ptunnel|pingtunnel" | grep -v grep
echo ""

echo "--- Connections to Cloud Services ---"
lsof -i -n -P 2>/dev/null | grep -iE "amazonaws|aws|cloudflare|azure|google|dropbox|box\.com"
echo ""

echo "--- Connections to CDN Services ---"
lsof -i -n -P 2>/dev/null | grep -iE "cdn|cloudfront|akamai|fastly"
echo ""

echo "--- Connections to File Hosting ---"
lsof -i -n -P 2>/dev/null | grep -iE "mega\.nz|wetransfer|sendspace|mediafire"
echo ""

echo "--- Unusual Destination Ports ---"
lsof -i -n -P 2>/dev/null | grep -vE ":80|:443|:22|:53|:25|:587|:993|:995|:110|:143" | grep -v LISTEN
echo ""

echo "--- Network Interface Byte Counts ---"
netstat -ib
echo ""

echo "--- Interface Statistics ---"
for iface in $(ifconfig -a | grep -o "^[a-z0-9]*:" | tr -d ":"); do
    echo "=== $iface ==="
    netstat -I $iface -b 2>/dev/null
    echo ""
done
echo ""

echo "--- Network Protocol Statistics ---"
netstat -s
echo ""

echo "--- Large Data Transfers ---"
log show --predicate 'eventMessage CONTAINS "bytes" OR eventMessage CONTAINS "transfer"' --last 7d 2>/dev/null | grep -E "[0-9]{6,}" | tail -300
echo ""

echo "--- Exfiltration Time Patterns ---"
log show --predicate 'subsystem == "com.apple.networkd"' --last 7d 2>/dev/null | awk '{print $1, $2}' | cut -d: -f1 | sort | uniq -c
echo ""

echo "--- Beacon Interval Detection ---"
lsof -i -n -P 2>/dev/null | awk '{print $1, $9}' | grep ESTABLISHED | sort
echo ""

echo "--- Persistent Long Connections ---"
lsof -i -n -P 2>/dev/null | grep ESTABLISHED | awk '{print $2}' | sort | uniq -c | sort -rn | head -20
echo ""

# ============================================================================
# CROSS-DEVICE AND MESH NETWORK EXPLOITATION
# ============================================================================

echo "=== CROSS-DEVICE AND MESH NETWORK EXPLOITATION ==="
echo ""

echo "--- Bluetooth Status ---"
system_profiler SPBluetoothDataType
echo ""

echo "--- Bluetooth Devices ---"
if command -v blueutil >/dev/null 2>&1; then
    blueutil --paired 2>/dev/null
    blueutil --connected 2>/dev/null
fi
echo ""

echo "--- Bluetooth Activity ---"
log show --predicate 'subsystem CONTAINS "bluetooth"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- AirDrop Activity ---"
log show --predicate 'subsystem CONTAINS "airdrop" OR subsystem CONTAINS "sharing"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Sharing Services Status ---"
sharing -l 2>/dev/null
echo ""

echo "--- AirDrop Transfers ---"
log show --predicate 'subsystem CONTAINS "airdrop" AND eventMessage CONTAINS "transfer"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Continuity Framework ---"
log show --predicate 'subsystem CONTAINS "continuity"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Handoff Activity ---"
log show --predicate 'subsystem CONTAINS "handoff"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Universal Clipboard ---"
log show --predicate 'subsystem CONTAINS "clipboard" OR subsystem CONTAINS "universalclipboard"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Clipboard Synchronization ---"
log show --predicate 'eventMessage CONTAINS "clipboard" AND eventMessage CONTAINS "sync"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- AirPlay Activity ---"
log show --predicate 'subsystem CONTAINS "airplay"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- AirPlay Receivers ---"
log show --predicate 'subsystem CONTAINS "airplay" AND eventMessage CONTAINS "receiver"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- Sidecar Activity ---"
log show --predicate 'subsystem CONTAINS "sidecar"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- AWDL Interface ---"
ifconfig awdl0 2>/dev/null
echo ""

echo "--- AWDL Activity Logs ---"
log show --predicate 'subsystem CONTAINS "awdl"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- AWDL Peers ---"
log show --predicate 'subsystem CONTAINS "awdl" AND eventMessage CONTAINS "peer"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Bonjour Services ---"
dns-sd -B _services._dns-sd._udp 2>&1 &
sleep 3
kill %1 2>/dev/null
echo ""

echo "--- Network Service Discovery ---"
log show --predicate 'process == "mDNSResponder" AND eventMessage CONTAINS "service"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- SMB/CIFS Activity ---"
ps aux | grep -iE "smb|cifs|samba" | grep -v grep
echo ""

echo "--- AFP (Apple File Protocol) ---"
ps aux | grep -i "afp" | grep -v grep
echo ""

echo "--- File Sharing Connections ---"
lsof -i :445 -i :139 -i :548 2>/dev/null
echo ""

echo "--- Printer Sharing ---"
lpstat -p 2>/dev/null
lpstat -v 2>/dev/null
echo ""

echo "--- CUPS Activity ---"
log show --predicate 'process == "cupsd"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Network Printers ---"
lpstat -a 2>/dev/null
echo ""

echo "--- Screen Sharing ---"
ps aux | grep -iE "screensharing|vnc|rfb|ard" | grep -v grep
echo ""

echo "--- Remote Desktop ---"
log show --predicate 'subsystem CONTAINS "remotedesktop" OR eventMessage CONTAINS "ARD"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- VNC Connections ---"
lsof -i :5900 -i :5901 -i :5902 2>/dev/null
echo ""

echo "--- IoT Device Connections ---"
arp -a | grep -iE "esp|arduino|raspberry|philips|nest|ring|alexa|google.home"
echo ""

echo "--- Smart Home Protocols ---"
log show --predicate 'eventMessage CONTAINS "homekit" OR eventMessage CONTAINS "matter" OR eventMessage CONTAINS "zigbee"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Chromecast/Media Devices ---"
dns-sd -B _googlecast._tcp 2>&1 &
sleep 3
kill %1 2>/dev/null
echo ""

# ============================================================================
# WIFI-BASED C2 COMMUNICATION
# ============================================================================

echo "=== WIFI-BASED C2 COMMUNICATION ==="
echo ""

echo "--- Cloud Service Connections ---"
lsof -i -n -P 2>/dev/null | grep -iE "amazonaws|aws|s3|ec2|cloudflare|azure|blob|googleusercontent|storage\.googleapis"
echo ""

echo "--- Specific Cloud Endpoints ---"
lsof -i -n -P 2>/dev/null | grep -iE "compute.*amazonaws|*.cloudfront.net|*.azureedge.net"
echo ""

echo "--- Social Media API Connections ---"
lsof -i -n -P 2>/dev/null | grep -iE "twitter|api\.twitter|telegram|discord|slack\.com|api\.slack"
echo ""

echo "--- Messaging Platform APIs ---"
lsof -i -n -P 2>/dev/null | grep -iE "whatsapp|signal|messenger|wechat"
echo ""

echo "--- Pastebin Services ---"
lsof -i -n -P 2>/dev/null | grep -iE "pastebin|paste|ghostbin|hastebin"
echo ""

echo "--- Code Hosting Connections ---"
lsof -i -n -P 2>/dev/null | grep -iE "github|gitlab|bitbucket|raw\.githubusercontent"
echo ""

echo "--- Blockchain Connections ---"
lsof -i -n -P 2>/dev/null | grep -iE "blockchain|bitcoin|ethereum|crypto|coinbase"
echo ""

echo "--- Cryptocurrency Activity ---"
ps aux | grep -iE "bitcoin|ethereum|monero|crypto|miner" | grep -v grep
echo ""

echo "--- P2P Network Activity ---"
lsof -i -n -P 2>/dev/null | grep -iE "torrent|p2p|bittorrent|utorrent"
echo ""

echo "--- P2P Processes ---"
ps aux | grep -iE "transmission|deluge|rtorrent|qbittorrent" | grep -v grep
echo ""

echo "--- Domain Generation Algorithm Patterns ---"
log show --predicate 'process == "mDNSResponder"' --last 7d 2>/dev/null | grep -oE "[a-z0-9]{15,}\.com|[a-z0-9]{15,}\.net|[a-z0-9]{15,}\.org" | head -200
echo ""

echo "--- Random Domain Queries ---"
log show --predicate 'process == "mDNSResponder"' --last 7d 2>/dev/null | grep -E "[a-z]{10,}" | tail -500
echo ""

echo "--- Fast Flux DNS Indicators ---"
log show --predicate 'process == "mDNSResponder"' --last 1d 2>/dev/null | awk '{for(i=1;i<=NF;i++) if ($i ~ /[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/) print $i}' | sort | uniq -c | sort -rn | head -50
echo ""

echo "--- Short-Lived DNS Responses ---"
log show --predicate 'process == "mDNSResponder" AND eventMessage CONTAINS "TTL"' --last 7d 2>/dev/null | grep -E "TTL.*[0-9]{1,3}" | tail -300
echo ""

echo "--- Dead Drop Resolver Activity ---"
log show --predicate 'eventMessage CONTAINS "pastebin" OR eventMessage CONTAINS "github" OR eventMessage CONTAINS "gitlab"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Onion/Dark Web Indicators ---"
log show --predicate 'eventMessage CONTAINS ".onion"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- TLS/SSL Connections Summary ---"
lsof -i :443 -n -P 2>/dev/null | awk '{print $9}' | cut -d: -f1 | sort | uniq -c | sort -rn
echo ""

echo "--- Certificate Validation Logs ---"
log show --predicate 'subsystem == "com.apple.securityd" AND eventMessage CONTAINS "certificate"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Unusual User Agents ---"
log show --predicate 'eventMessage CONTAINS "User-Agent" OR eventMessage CONTAINS "user agent"' --last 7d 2>/dev/null | tail -200
echo ""

# ============================================================================
# WIFI ADVERTISING AND TRACKING
# ============================================================================

echo "=== WIFI ADVERTISING AND TRACKING ==="
echo ""

echo "--- WiFi Probe Requests ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "probe"' --last 7d 2>/dev/null | tail -1000
echo ""

echo "--- Probe Request Frequency ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "probe"' --last 1d 2>/dev/null | wc -l
echo ""

echo "--- MAC Address Randomization ---"
log show --predicate 'eventMessage CONTAINS "random" AND eventMessage CONTAINS "MAC"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- MAC Address Changes ---"
log show --predicate 'subsystem == "com.apple.wifi" AND eventMessage CONTAINS "MAC address"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Hardware Address History ---"
log show --predicate 'eventMessage CONTAINS "hardware address"' --last 30d 2>/dev/null | tail -300
echo ""

echo "--- Location Services for Apps ---"
log show --predicate 'subsystem == "com.apple.locationd" AND eventMessage CONTAINS "wifi"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- WiFi-Based Location Tracking ---"
log show --predicate 'subsystem == "com.apple.locationd" AND eventMessage CONTAINS "scan"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- App Network Activity ---"
log show --predicate 'eventMessage CONTAINS "application" AND eventMessage CONTAINS "network"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Analytics Data Collection ---"
find ~/Library/Application\ Support -name "*analytic*" -o -name "*telemetry*" 2>/dev/null -exec ls -la {} \;
echo ""

echo "--- Telemetry Uploads ---"
log show --predicate 'eventMessage CONTAINS "telemetry" OR eventMessage CONTAINS "analytics"' --last 7d 2>/dev/null | tail -500
echo ""

echo "--- Tracking Beacons ---"
log show --predicate 'eventMessage CONTAINS "beacon" OR eventMessage CONTAINS "tracking"' --last 7d 2>/dev/null | tail -300
echo ""

echo "--- Marketing SDK Activity ---"
log show --predicate 'eventMessage CONTAINS "marketing" OR eventMessage CONTAINS "advertising"' --last 7d 2>/dev/null | tail -200
echo ""

echo "--- Third-Party Trackers ---"
lsof -i -n -P 2>/dev/null | grep -iE "doubleclick|google-analytics|facebook|criteo|taboola"
echo ""

echo ""
echo "========================================="
echo "Script 3 Complete: $(date)"
echo "========================================="
echo ""